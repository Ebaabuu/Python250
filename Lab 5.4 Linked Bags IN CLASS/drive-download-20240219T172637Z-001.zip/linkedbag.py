"""
File: linkedbag.py
"""

from baginterface import BagInterface
from node import Node

class LinkedBag(BagInterface):
    """A link-based bag implementation."""

    def __init__(self, sourceCollection = None):
        """Sets the initial state of self, which includes the
        contents of sourceCollection, if it's present."""
        
        # FINISH ME
        pass

    def isEmpty(self):
        """Returns True if len(self) == 0, or False otherwise."""
        
        # FINISH ME
        return 0
    
    def __len__(self):
        """-Returns the number of items in self."""
        
        # FINISH ME
        return 0

    def clear(self):
        """Makes self become empty."""
        
        # FINISH ME
        pass  

    def add(self, item):
        """Adds item to self."""
        
        # FINISH ME
        pass

    def __str__(self):
        """Returns the string representation of self."""

        # Below is the clever Pythonic way
        #return "{" + ", ".join(map(str, self)) + "}"
        
        bagString = ""
        
        # FINISH ME
                    
        bagString = "{" + bagString + "}"
        
        return bagString 
    
    def count(self, item):
        """Returns the number of instances of the item in the bag."""
        
        # FINISH ME
        return 0

    def remove(self, item):
        """Precondition: item is in self.
        Raises: KeyError if item in not in self.
        Postcondition: item is removed from self."""
        
        # FINISH ME
        pass

    def __eq__(self, other):
        """Returns True if self equals other,
        or False otherwise."""

        # FINISH ME
        return True    

    def __add__(self, other):
        """Returns a new bag containing the contents
        of self and other."""
        
        # FINISH ME
        return LinkedBag()        
       
    def __iter__(self):
        """Supports iteration over a view of self."""
        
        cursor = self.head
        while cursor != None:
            yield cursor.data
            cursor = cursor.next