"""
File: node.py
"""

class Node(object):
    """Represents a single node in a linked chain."""

    # FINISH ME
